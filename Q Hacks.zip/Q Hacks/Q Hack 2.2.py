#! /usr/bin/python3

import sys
from pennylane import numpy as np
import pennylane as qml
from math import inf
from heapq import heapify, heappush, heappop
from pprint import PrettyPrinter

graph = {
    0: [1],
    1: [0, 2, 3, 4],
    2: [1],
    3: [1],
    4: [1, 5, 7, 8],
    5: [4, 6],
    6: [5, 7],
    7: [4, 6],
    8: [4],
}

def dijsktra(graph,src):
    
    node_data = dict([(i,{'cost':inf,'parent':[]}) for i in range(9)])
    visited =  dict([(i,0) for i in range(9)])

    node_data[src] = { 'cost' : 0,
                       'parent' : -1 
    }
    
    visited[src] = 1

    minheap = [(0,src)]

    while len(minheap) != 0 :
        (curnode_cost,cur_node) = heappop(minheap)
        for node in graph[cur_node]:
            if node_data[node]['cost'] > curnode_cost + 1 :
                node_data[node]['cost'] = curnode_cost + 1
                node_data[node]['parent'] = cur_node
                heappush(minheap,(curnode_cost + 1,node))

    # print("Shortest Distance: " + str(node_data[dest]['cost']))
    # print("Shortest Path: " + str(node_data[dest]['pred'] + list(dest)))
    return node_data


def n_swaps(cnot):
    """Count the minimum number of swaps needed to create the equivalent CNOT.

    Args:
        - cnot (qml.Operation): A CNOT gate that needs to be implemented on the hardware
        You can find out the wires on which an operator works by asking for the 'wires' attribute: 'cnot.wires'

    Returns:
        - (int): minimum number of swaps
    """
    src , dest = cnot.wires
    node_data = dijsktra(graph,src)
    return 2*(node_data[dest]['cost']-1)

    # QHACK #

    # QHACK #


if __name__ == "__main__":
    # DO NOT MODIFY anything in this code block
    inputs = sys.stdin.read().split(",")
    output = n_swaps(qml.CNOT(wires=[int(i) for i in inputs]))
    print(f"{output}")