# -*- coding: utf-8 -*-
"""
Created on Thu Feb 24 09:05:40 2022

@author: avina
"""
# -*- coding: utf-8 -*-

import sys
import pennylane as qml
from pennylane import numpy as np
def deutsch_jozsa(oracle):
    """This function will determine whether an oracle defined by a function f is constant or balanced.
    Args:
        - oracle (function): Encoding of the f function as a quantum gate. The first two qubits refer to the input and the third to the output.
    Returns:
        - (str): "constant" or "balanced"
    """

    dev0 = qml.device('default.qubit', wires=3,shots=1)
    
    @qml.qnode(dev0)

    numbers = [int(i) for i in inputs]

    def oracle():
        for i in numbers:
            qml.CNOT(wires=[i, 2])

   def circuit():
       qml.Hadamard(wires=0)
       qml.Hadamard(wires=1)
       qml.RX(np.pi/2,wires=2)
       qml.Hadamard(wires=2)
       oracle()
       qml.Hadamard(wires=0)
       qml.Hadamard(wires=1)
       return qml.expval(qml.PauliZ(0) @ qml.PauliZ(1))
       return qml.sample(wires=range(2))
   sample = circuit()
   

if __name__ == "__main__":
    # DO NOT MODIFY anything in this code block
    inputs = sys.stdin.read().split(",")
    numbers = [int(i) for i in inputs]

    def oracle():
        for i in numbers:
            qml.CNOT(wires=[i, 2])

    output = deutsch_jozsa(oracle)
    print(output)
    
